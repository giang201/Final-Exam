package com.vti.shopee.controller;

import com.vti.shopee.model.Product;
import com.vti.shopee.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping(path  = "/api/v1/Product")
public class ProductController {
    @Autowired
    com.vti.shopee.repository.ProductRepository productRepository;
    @GetMapping("/getProduct")
    List<com.vti.shopee.model.Product> getListProduct()
    {
        return productRepository.findAll();
    }

    @PostMapping("/insertProduct")
    com.vti.shopee.model.Product insert (@RequestBody com.vti.shopee.model.Product product)
    {
        return  productRepository.save(product);
    }

    @GetMapping("/{id}")
    Product getProductInfo(@PathVariable Long id) {

        Optional<Product> optionalProduct =   productRepository.findById(id);
        if(optionalProduct.isPresent())
        {
            return optionalProduct.get();
        }
        return null;
    }
}



