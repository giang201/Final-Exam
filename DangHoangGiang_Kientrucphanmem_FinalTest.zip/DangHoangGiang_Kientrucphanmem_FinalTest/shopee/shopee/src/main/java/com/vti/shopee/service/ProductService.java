package com.vti.shopee.service;

import com.vti.shopee.model.Product;
import com.vti.shopee.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.List;
@Service
@Configurable
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    public List<Product> getProductPage(int pageNum, int pageSize)
    {
        Pageable pageOne = PageRequest.of(pageNum,pageSize);
        List<Product> returnList = new ArrayList<>();
        Page<Product> allProduct = productRepository.findAll(pageOne);
        return allProduct.stream().toList();
    }
    public List<Product>  searchProductByName(String keyword)
    {
        List<Product> returnList = new ArrayList<>();

        for(Product product: productRepository.findAll())
        {
            if(product.getName().toLowerCase().trim().replace(" ","")
                    .contains(keyword.toLowerCase().trim().replace(" ","")))
            {
                returnList.add(product);
            }

        }
        return returnList;
    }
}
